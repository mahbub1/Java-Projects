package criminal;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;


/* @author Mahbub */
public class One extends javax.swing.JFrame {

  
    public One() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        usern = new javax.swing.JTextField();
        pass = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        password = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        jLabel5.setText("jLabel5");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        usern.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernActionPerformed(evt);
            }
        });
        jPanel1.add(usern);
        usern.setBounds(100, 120, 160, 30);

        pass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passActionPerformed(evt);
            }
        });
        jPanel1.add(pass);
        pass.setBounds(100, 170, 160, 30);

        jButton1.setBackground(new java.awt.Color(63, 21, 27));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(200, 220, 60, 30);

        jLabel2.setFont(new java.awt.Font("Showcard Gothic", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Welcome to Crime house");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(110, 0, 350, 70);

        jLabel3.setBackground(new java.awt.Color(255, 255, 153));
        jLabel3.setFont(new java.awt.Font("Plantagenet Cherokee", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 0));
        jLabel3.setText("If you face any problem to LOGIN, please contact @ 01680161682 (Mahbub, Developer)");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 300, 550, 20);

        username.setBackground(new java.awt.Color(111, 61, 61));
        username.setForeground(new java.awt.Color(255, 255, 255));
        username.setText("User name");
        jPanel1.add(username);
        username.setBounds(20, 120, 70, 30);

        password.setBackground(new java.awt.Color(111, 61, 61));
        password.setForeground(new java.awt.Color(255, 255, 255));
        password.setText("Passcode");
        jPanel1.add(password);
        password.setBounds(20, 170, 60, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/criminal/guns-girls-mania-mixed-girl-aiming-a-pistol-at-you-90190.jpg"))); // NOI18N
        jLabel1.setMaximumSize(new java.awt.Dimension(580, 350));
        jLabel1.setMinimumSize(new java.awt.Dimension(580, 350));
        jLabel1.setPreferredSize(new java.awt.Dimension(580, 350));
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, -10, 580, 350);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
   
        // TODO add your handling code here:
        String Password = pass.getText();
        String Username = usern.getText();
        if(Password.contains("mahbub123")&& Username.contains("mahbub"))
        
        {
        
        usern.setText("");
        pass.setText("");
        close();
        home h =new home();
            h.setVisible(true);
        
        }
        else{
        JOptionPane.showMessageDialog(null,"This Password is Wrong\n click ok and try again");
        pass.setText("");
        usern.setText("");
        
        }
        
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void passActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passActionPerformed

    private void usernActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernActionPerformed

 
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
             
                new One().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField pass;
    private javax.swing.JLabel password;
    private javax.swing.JTextField usern;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables


private void close(){

WindowEvent winClosing=new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosing);
}

}
